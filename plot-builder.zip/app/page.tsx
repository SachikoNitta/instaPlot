"use client"

import PlotBuilder from "../plot-builder"

export default function Page() {
  return <PlotBuilder />
}
